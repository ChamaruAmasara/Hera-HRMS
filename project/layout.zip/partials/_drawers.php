<!--begin::Drawers-->
<?php include 'partials/drawers/_activity-drawer.php' ?>
<?php include 'partials/drawers/_chat-messenger.php' ?>
<?php include 'partials/drawers/_shopping-cart.php' ?>
<!--end::Drawers-->