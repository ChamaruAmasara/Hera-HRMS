<!--begin::Footer-->
<div class="app-sidebar-footer flex-column-auto pt-2 pb-6 px-6 app-sidebar-logo" id="kt_app_sidebar_footer">
	<div class="opacity-25">
		<div class="fw-bold text-primary h-25px app-sidebar-logo-default">Powered By</div>
		<div class="fw-bold text-primary h-20px app-sidebar-logo-minimize"></div>
		
		<div class="text-primary app-sidebar-logo-minimize"></div>
		<img alt="Logo" src="assets/media/logos/HERA-logo.png" class="h-25px app-sidebar-logo-default" />
		<img alt="Logo" src="assets/media/logos/HERA-logo.png" class="h-10px app-sidebar-logo-minimize" />
	</div>
	</div>
<!--end::Footer-->